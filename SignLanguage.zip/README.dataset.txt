# SignLanguage > 2024-08-14 7:50am
https://universe.roboflow.com/son-nguyen-ngoc/signlanguage-zamfg

Provided by a Roboflow user
License: CC BY 4.0

